$(function() {
  var show = 1;
    
    $('.show').on('click', function(){
        
        if(show == 1){
            $('.content-menu').addClass("content-menu2");
            show = 0;
        }else{
            $('.content-menu').removeClass("content-menu2");
            show = 1;
        }
        
        
    })

  "uso estricto"
  
  var init = "No hay productos!";
  var counter = 0;

  // Initial Cart
  $(".counter").html(init);
  
  // Add Items To Basket
  function addToBasket() {
    counter++;
    $(".counter").html(counter).animate({
      'opacity' : '0'
    },300, function() {
      $(".counter").delay(300).animate({
        'opacity' : '1'
      })
    })
  }

  // Add To Basket Animation
  $("button").on("click", function() {
    addToBasket(); $(this).parent().parent().find(".product_overlay").css({
      'transform': ' translateY(0px)',
      'opacity': '1',
      'transition': 'all ease-in-out .45s'
    }).delay(1500).queue(function() {
      $(this).css({
        'transform': 'translateY(-500px)',
        'opacity': '0',
        'transition': 'all ease-in-out .45s'
      }).dequeue();
    });
  });
});

function ajaxget(){
  var conexion;
  if (window.XMLHttpRequest) {
    conexion = new XMLHttpRequest();
  }else{
    conexion = new ActiveXObject("Microsoft.XMLHTTP");
  }
  conexion.onreadystatechange = function(){
    if (conexion.readyState == 4 && conexion.status == 200) {
      document.getElementById("midiv").innerHTML = conexion.responseText; 
    }
  }
  conexion.open("GET","form/f_anadir.jsp");
  conexion.send();
}
function ajaxget2(){
  var conexion;
  if (window.XMLHttpRequest) {
    conexion = new XMLHttpRequest();
  }else{
    conexion = new ActiveXObject("Microsoft.XMLHTTP");
  }
  conexion.onreadystatechange = function(){
    if (conexion.readyState == 4 && conexion.status == 200) {
      document.getElementById("midiv").innerHTML = conexion.responseText; 
    }
  }
  conexion.open("GET","form/f_eliminar.jsp");
  conexion.send();
}